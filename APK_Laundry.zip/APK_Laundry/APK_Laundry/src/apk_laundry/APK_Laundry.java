/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package apk_laundry;

/**
 *
 * @author Erwin D
 * @author Kelvin P
 */
public class APK_Laundry {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        koneksi k = new koneksi () ;
        k.connect();
    }
    
}
